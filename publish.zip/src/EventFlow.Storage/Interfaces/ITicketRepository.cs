
using EventFlow.Storage.Entities;

namespace EventFlow.Storage.Interfaces;

public interface ITicketRepository
{
    Task AddTicketAsync(
        string tenantId,
        TicketEntity ticket);

    Task<TicketEntity?> GetTicketAsync(
        string tenantId,
        string eventId,
        string ticketNumber);

    Task<List<TicketEntity>> GetTicketsByEventAsync(
        string tenantId,
        string eventId);

    Task UpdateTicketAsync(
        string tenantId,
        TicketEntity ticket);
}
