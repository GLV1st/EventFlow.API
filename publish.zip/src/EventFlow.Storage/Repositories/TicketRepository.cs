
using Azure;
using Azure.Data.Tables;
using EventFlow.Storage.Entities;
using EventFlow.Storage.Interfaces;
using Microsoft.Extensions.Configuration;

namespace EventFlow.Storage.Repositories;

public class TicketRepository : ITicketRepository
{
    private readonly TableClient _table;

    public TicketRepository(IConfiguration configuration)
    {
        var connectionString = configuration["StorageConnection"];

        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new InvalidOperationException(
                "StorageConnection configuration is missing.");
        }

        _table = new TableClient(connectionString, "Tickets");
    }

    private async Task EnsureTableAsync()
    {
        await _table.CreateIfNotExistsAsync();
    }

    private static string BuildPartitionKey(
        string tenantId,
        string eventId)
    {
        if (string.IsNullOrWhiteSpace(tenantId))
            throw new ArgumentException("TenantId is required.");

        if (string.IsNullOrWhiteSpace(eventId))
            throw new ArgumentException("EventId is required.");

        if (tenantId.Contains('|') || eventId.Contains('|'))
            throw new ArgumentException(
                "TenantId and EventId cannot contain '|'.");
        
        return $"{tenantId}|{eventId}";
    }

    public async Task AddTicketAsync(
        string tenantId,
        TicketEntity ticket)
    {
        ArgumentNullException.ThrowIfNull(ticket);

        var partitionKey = BuildPartitionKey(
            tenantId,
            ticket.EventId);

        if (!string.IsNullOrWhiteSpace(ticket.TenantId) &&
            ticket.TenantId != tenantId)
        {
            throw new InvalidOperationException(
                "Ticket tenant does not match the authenticated tenant.");
        }

        ticket.TenantId = tenantId;
        ticket.PartitionKey = partitionKey;

        if (string.IsNullOrWhiteSpace(ticket.RowKey))
        {
            throw new ArgumentException(
                "Ticket number (RowKey) is required.");
        }

        await EnsureTableAsync();
        await _table.AddEntityAsync(ticket);
    }

    public async Task<TicketEntity?> GetTicketAsync(
        string tenantId,
        string eventId,
        string ticketNumber)
    {
        var partitionKey = BuildPartitionKey(tenantId, eventId);

        if (string.IsNullOrWhiteSpace(ticketNumber))
            throw new ArgumentException("Ticket number is required.");

        await EnsureTableAsync();

        try
        {
            var result = await _table.GetEntityAsync<TicketEntity>(
                partitionKey,
                ticketNumber);

            return result.Value;
        }
        catch (RequestFailedException ex) when (ex.Status == 404)
        {
            return null;
        }
    }

    public async Task<List<TicketEntity>> GetTicketsByEventAsync(
        string tenantId,
        string eventId)
    {
        var partitionKey = BuildPartitionKey(tenantId, eventId);

        await EnsureTableAsync();

        var tickets = new List<TicketEntity>();

        await foreach (var ticket in _table.QueryAsync<TicketEntity>(
            t => t.PartitionKey == partitionKey))
        {
            tickets.Add(ticket);
        }

        return tickets;
    }

    public async Task UpdateTicketAsync(
        string tenantId,
        TicketEntity ticket)
    {
        ArgumentNullException.ThrowIfNull(ticket);

        var expectedPartitionKey = BuildPartitionKey(
            tenantId,
            ticket.EventId);

        if (!string.Equals(
            ticket.TenantId,
            tenantId,
            StringComparison.Ordinal))
        {
            throw new InvalidOperationException(
                "Ticket tenant does not match the authenticated tenant.");
        }

        if (!string.Equals(
            ticket.PartitionKey,
            expectedPartitionKey,
            StringComparison.Ordinal))
        {
            throw new InvalidOperationException(
                "Ticket partition does not match the authenticated tenant and event.");
        }

        await EnsureTableAsync();

        await _table.UpdateEntityAsync(
            ticket,
            ticket.ETag);
    }
}
