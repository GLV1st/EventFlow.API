
using Azure;
using EventFlow.Api.Security;
using EventFlow.Shared.DTOs;
using EventFlow.Storage.Entities;
using EventFlow.Storage.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using System.Net;
using System.Security.Cryptography;

namespace EventFlow.Api.Functions;

public class GenerateTicketsFunction
{
    private readonly IEventRepository _events;
    private readonly ITicketRepository _tickets;
    private readonly ITenantSecurityService _tenantSecurity;

    public GenerateTicketsFunction(
        IEventRepository events,
        ITicketRepository tickets,
        ITenantSecurityService tenantSecurity)
    {
        _events = events;
        _tickets = tickets;
        _tenantSecurity = tenantSecurity;
    }

    [Function("GenerateTickets")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(
            AuthorizationLevel.Anonymous,
            "post",
            Route = "tickets/generate")]
        HttpRequestData req)
    {
        // Authenticate the tenant using its bearer token.
        if (!req.Headers.TryGetValues("Authorization", out var values))
        {
            return req.CreateResponse(HttpStatusCode.Unauthorized);
        }

        var authHeader = values.FirstOrDefault();

        if (string.IsNullOrWhiteSpace(authHeader) ||
            !authHeader.StartsWith(
                "Bearer ",
                StringComparison.OrdinalIgnoreCase))
        {
            return req.CreateResponse(HttpStatusCode.Unauthorized);
        }

        var accessToken = authHeader["Bearer ".Length..].Trim();

        if (string.IsNullOrWhiteSpace(accessToken))
        {
            return req.CreateResponse(HttpStatusCode.Unauthorized);
        }

        var tenantId =
            await _tenantSecurity.ValidateAccessTokenAsync(accessToken);

        if (string.IsNullOrWhiteSpace(tenantId))
        {
            return req.CreateResponse(HttpStatusCode.Unauthorized);
        }

        var request =
            await req.ReadFromJsonAsync<GenerateTicketsRequest>();

        if (request == null)
        {
            return await ErrorResponse(
                req,
                HttpStatusCode.BadRequest,
                "Invalid request.");
        }

        if (string.IsNullOrWhiteSpace(request.EventId))
        {
            return await ErrorResponse(
                req,
                HttpStatusCode.BadRequest,
                "EventId is required.");
        }

        if (string.IsNullOrWhiteSpace(request.EventName))
        {
            return await ErrorResponse(
                req,
                HttpStatusCode.BadRequest,
                "EventName is required.");
        }

        if (string.IsNullOrWhiteSpace(request.TicketPrefix))
        {
            return await ErrorResponse(
                req,
                HttpStatusCode.BadRequest,
                "TicketPrefix is required.");
        }

        if (request.Quantity <= 0)
        {
            return await ErrorResponse(
                req,
                HttpStatusCode.BadRequest,
                "Quantity must be greater than zero.");
        }

        // Find the event within this tenant.
        var evt = await _events.GetEventAsync(
            tenantId,
            request.EventId);

        // Automatically create the event when the first purchase arrives.
        if (evt == null)
        {
            var newEvent = new EventEntity
            {
                TenantId = tenantId,
                PartitionKey = tenantId,
                RowKey = request.EventId,
                Name = request.EventName.Trim(),
                TicketPrefix = request.TicketPrefix
                    .Trim()
                    .ToUpperInvariant(),
                NextTicketNumber = 1
            };

            try
            {
                await _events.AddEventAsync(tenantId, newEvent);
                evt = newEvent;
            }
            catch (RequestFailedException ex) when (ex.Status == 409)
            {
                // Another request may have created the event first.
                evt = await _events.GetEventAsync(
                    tenantId,
                    request.EventId);

                if (evt == null)
                {
                    return await ErrorResponse(
                        req,
                        HttpStatusCode.Conflict,
                        "Event creation conflict. Please retry.");
                }
            }
        }

        if (string.IsNullOrWhiteSpace(evt.TicketPrefix))
        {
            return await ErrorResponse(
                req,
                HttpStatusCode.InternalServerError,
                "Event has no ticket prefix.");
        }

        // Reserve ticket numbers atomically for this tenant and event.
        int firstTicketNumber;

        try
        {
            firstTicketNumber =
                await _events.ReserveTicketNumbersAsync(
                    tenantId,
                    request.EventId,
                    request.Quantity);
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"FAILED TO RESERVE TICKET NUMBERS: {ex}");

            return await ErrorResponse(
                req,
                HttpStatusCode.InternalServerError,
                "Unable to reserve ticket numbers.");
        }

        // Generate the tickets.
        var response = new List<GenerateTicketsResponse>();

        for (int i = 0; i < request.Quantity; i++)
        {
            var ticketNumber =
                $"{evt.TicketPrefix}-{(firstTicketNumber + i):D6}";

            var now = DateTime.UtcNow;

            var ticket = new TicketEntity
            {
                TenantId = tenantId,
                EventId = request.EventId,
                PartitionKey = $"{tenantId}|{request.EventId}",
                RowKey = ticketNumber,

                OrderId = request.OrderId,
                TicketType = request.TicketType,
                EventDate = request.EventDate,
                CustomerName = request.CustomerName,
                CustomerEmail = request.CustomerEmail,

                WalletToken =
                    Convert.ToHexString(
                        RandomNumberGenerator.GetBytes(32))
                    .ToLowerInvariant(),

                CheckedIn = false,
                CheckedInAt = null,
                CheckedOut = false,
                CheckedOutAt = null,
                Cancelled = false,
                FirstScanAt = null,
                Created = now,
                Updated = now
            };

            await _tickets.AddTicketAsync(tenantId, ticket);

            response.Add(new GenerateTicketsResponse
            {
                TicketNumber = ticketNumber,
                WalletToken = ticket.WalletToken
            });
        }

        var http = req.CreateResponse(HttpStatusCode.OK);

        await http.WriteAsJsonAsync(response);

        return http;
    }

    private static async Task<HttpResponseData> ErrorResponse(
        HttpRequestData req,
        HttpStatusCode status,
        string message)
    {
        var response = req.CreateResponse(status);

        await response.WriteAsJsonAsync(new
        {
            Status = "ERROR",
            Message = message
        });

        return response;
    }
}
